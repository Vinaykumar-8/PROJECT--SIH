import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import { router } from 'expo-router';
import { MapPin, Shield, Users, Clock } from 'lucide-react-native';

export default function HomeScreen() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeToursCount, setActiveToursCount] = useState(0);

  useEffect(() => {
    // Check if user is logged in (in real app, check from secure storage)
    const checkLoginStatus = () => {
      // For demo, assume user needs to login first
      setIsLoggedIn(false);
    };
    checkLoginStatus();
  }, []);

  const handleEmergencyCall = () => {
    Alert.alert(
      'Emergency Contacts',
      'Tourist Helpline: 1363\nPolice: 100\nAmbulance: 108\nFire: 101',
      [{ text: 'OK' }]
    );
  };

  if (!isLoggedIn) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Northeast Tourism</Text>
          <Text style={styles.headerSubtitle}>Safety & Security</Text>
        </View>

        <ScrollView style={styles.content}>
          <View style={styles.welcomeCard}>
            <Text style={styles.welcomeTitle}>Welcome to Northeast India</Text>
            <Text style={styles.welcomeText}>
              Your safety is our priority. Please register to access our comprehensive 
              tourist safety and security services.
            </Text>
          </View>

          <View style={styles.featuresGrid}>
            <View style={styles.featureCard}>
              <MapPin size={32} color="#16a34a" />
              <Text style={styles.featureTitle}>Live Tracking</Text>
              <Text style={styles.featureText}>Real-time location monitoring</Text>
            </View>
            
            <View style={styles.featureCard}>
              <Shield size={32} color="#dc2626" />
              <Text style={styles.featureTitle}>Emergency Alert</Text>
              <Text style={styles.featureText}>Instant emergency contacts</Text>
            </View>
            
            <View style={styles.featureCard}>
              <Users size={32} color="#7c3aed" />
              <Text style={styles.featureTitle}>Group Safety</Text>
              <Text style={styles.featureText}>Manage dependents</Text>
            </View>
            
            <View style={styles.featureCard}>
              <Clock size={32} color="#ea580c" />
              <Text style={styles.featureTitle}>Tour Updates</Text>
              <Text style={styles.featureText}>Real-time notifications</Text>
            </View>
          </View>

          <TouchableOpacity 
            style={styles.loginButton}
            onPress={() => router.push('/login')}
          >
            <Text style={styles.loginButtonText}>Login / Register</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.emergencyButton}
            onPress={handleEmergencyCall}
          >
            <Shield size={24} color="#ffffff" />
            <Text style={styles.emergencyButtonText}>Emergency Contacts</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Dashboard</Text>
        <Text style={styles.headerSubtitle}>Welcome back!</Text>
      </View>
      
      <ScrollView style={styles.content}>
        <View style={styles.statsCard}>
          <Text style={styles.statsTitle}>Active Tours: {activeToursCount}</Text>
        </View>
        
        <TouchableOpacity 
          style={styles.quickActionButton}
          onPress={() => router.push('/(tabs)/tours')}
        >
          <Text style={styles.quickActionText}>Start New Tour</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#16a34a',
    padding: 20,
    paddingTop: 60,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#bbf7d0',
    marginTop: 4,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  welcomeCard: {
    backgroundColor: '#ffffff',
    padding: 24,
    borderRadius: 16,
    marginBottom: 24,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  welcomeTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 12,
  },
  welcomeText: {
    fontSize: 16,
    color: '#6b7280',
    lineHeight: 24,
  },
  featuresGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 32,
  },
  featureCard: {
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 12,
    width: '48%',
    alignItems: 'center',
    marginBottom: 16,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
  },
  featureTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginTop: 12,
    marginBottom: 8,
  },
  featureText: {
    fontSize: 14,
    color: '#6b7280',
    textAlign: 'center',
  },
  loginButton: {
    backgroundColor: '#16a34a',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 16,
  },
  loginButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '600',
  },
  emergencyButton: {
    backgroundColor: '#dc2626',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
  },
  emergencyButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  statsCard: {
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
  },
  statsTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1f2937',
  },
  quickActionButton: {
    backgroundColor: '#16a34a',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  quickActionText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});